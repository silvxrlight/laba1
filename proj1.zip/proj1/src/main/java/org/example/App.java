package org.example;

import org.example.Controller.Controller;

public class App {
    public static void main(String[] args) {
        // Создаем контроллер и запускаем приложение
        Controller controller = new Controller();
        controller.startApp();
    }
}